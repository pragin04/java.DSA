import java.util.Scanner;
class Node {
    int data;
    Node prev;
    Node next;
    Node(int val) {
        data = val;
        prev = null;
        next = null;
    }
}
class DoublyLinkedList {
    Node head;
    DoublyLinkedList() {
        head = null;
    }
    void insert(int val) {
        Node newNode = new Node(val);
        if (head == null) {
            head = newNode;
            return;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newNode;
        newNode.prev = temp;
    }
    void convertToCircular() {
        if (head == null)
            return;
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = head;
        head.prev = temp;
    }
    void displayCircular() {
        if (head == null)
            return;
        Node temp = head;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != head);
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DoublyLinkedList l = new DoublyLinkedList();
        int val;
        do {
            val = sc.nextInt();
            if (val != -1)
                l.insert(val);
        } while (val != -1);
        l.convertToCircular();
        l.displayCircular();
    }
}