import java.util.Scanner;
public class Main {
	class Node {
		int data;
		Node next;
		Node prev;
		Node(int data) {
			this.data = data;
		}
	}
	Node head = null;
	public void insert(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			return;
		}
		Node temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}
		temp.next = newNode;
		newNode.prev = temp;
	}
	void rotate(int k) {
		if (head == null || head.next == null || k == 0) {
			return;
		}
		Node temp = head;
		int len = 1;
		while (temp.next != null) {
			temp = temp.next;
			len++;
		}
		Node tail = temp;
		k = k % len;
		if (k == 0) return;
		tail.next = head;
		head.prev = tail;
		Node curr = head;
		for (int i = 1; i < len - k; i++) {
			curr = curr.next;
		}
		Node newHead = curr.next;
		curr.next = null;
		newHead.prev = null;
		head = newHead;
	}
	public void display() {
		if (head == null) {
			System.out.println("List is Empty");
			return;
		}
		Node temp = head;
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.next;
		}
		System.out.println();
	}   
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Main l1 = new Main();
		int n = sc.nextInt();
		for (int i = 0; i < n; i++) {
			l1.insert(sc.nextInt());
		}
		int k = sc.nextInt();
		l1.rotate(k);
		l1.display();
	}
}