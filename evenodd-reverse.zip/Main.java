import java.util.*;
class Node {
int data;
Node next;
Node(int val) {
data=val;
next=null;
}
}
class Linked {
Node head;

void insertbeg(int val) {
Node newNode=new Node(val);
newNode.next=head;
head=newNode;
}
void display() {
if(head==null) {
System.out.print("Empty");
return;
}
Node temp=head;
while(temp!=null) {
System.out.print(temp.data + " ");
temp=temp.next;
}
}
}
public class Main {
public static void main(String[]args) {
Scanner sc=new Scanner(System.in);
Linked  evenlist=new Linked ();
        Linked  oddlist=new Linked ();
int n=sc.nextInt();

for(int i=0; i<n; i++) {
int val=sc.nextInt();
if(val%2==0)
evenlist.insertbeg(val);
else
oddlist.insertbeg(val);
}
if(evenlist.head==null){
   oddlist.display();
   return;
}
Node temp=evenlist.head;
while(temp.next!=null){
   temp=temp.next;
}
temp.next=oddlist.head;
evenlist.display();
}
}