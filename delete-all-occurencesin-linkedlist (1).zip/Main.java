import java.util.*;

class Node{
    int data;
    Node next;
    Node (int data){
        this.data=data;
        this.next=null;
    }
}

public class Main{
    Node head;

    void insertatend(int data){
        Node newNode=new Node(data);
        if(head==null){
            head=newNode;
            return;
        }
        Node temp=head;
        while(temp.next!=null){
            temp=temp.next;
        }
        temp.next=newNode;
    }

    void display(){
        if(head==null){
            System.out.println("empty");
            return;
        }
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;  
        }
    }

    void delete(int n){
        while(head!=null && head.data==n){
            head=head.next;
        }
        Node curr=head;
        while(curr!=null && curr.next!=null){
            if(curr.next.data==n){
                curr.next=curr.next.next;
            }else{
                curr=curr.next;
            }
        }
    }

    public static void main(String[]args){
        Scanner sc= new Scanner(System.in);
        Main list=new Main();

        int k=sc.nextInt();
        for(int i=0;i<k;i++){
            list.insertatend(sc.nextInt());
        }

        int n=sc.nextInt();
        list.delete(n);
        list.display();
    }
}