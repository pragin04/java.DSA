import java.util.*;
class Node{
    int data;
    Node next;
Node(int data){
    this.data=data;
    this.next=null;
}    
}
public class Main{
    Node head;
    void insert(int data){
        Node newNode=new Node(data);
        if(head==null){
            head=newNode;
            return;
        }
        Node temp=head;
        while(temp.next!=null){
            temp=temp.next;
        }
         temp.next=newNode;
    }
    void delete(){
        if(head==null){
            System.out.print("empty");
            return;
        }
        head=head.next;
        
}
    void display(){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        Main list=new Main();
        int n= sc.nextInt();
        for(int i=0;i<n;i++){
            int data=sc.nextInt();
            list.insert(data);
        }
        
        list.delete();
        list.display();
        }
    }
    
   