import java.util.*;
class Node{
    int data;
    Node next;
    Node (int data){
        this.data=data;
        this.next=null;
    }
}
public class Main{
    Node top;
    void push(int data){
        Node newNode=new Node(data);
        if(top==null){
            top=newNode;
            return;
        }
        newNode.next=top;
        top=newNode;
    }
    void sort(){
        if(top==null && top.next!=null)
            return ;
       
            for(Node i=top;i!=null;i=i.next){
            for(Node j=i.next;j!=null;j=j.next){
                if(i.data>j.data){
                    int temp=i.data;
                    i.data=j.data;
                    j.data=temp;
                }
        }
        }
    }
    void display(){
        Node temp=top;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
    public static void main(String[]args){
        Scanner sc=new Scanner (System.in);
            Main list=new Main();
            int n=sc.nextInt();
            for(int i=0;i<n;i++){
                int data=sc.nextInt();
                list.push(data);
            }
            list.sort();
            list.display();
        }
   
}
