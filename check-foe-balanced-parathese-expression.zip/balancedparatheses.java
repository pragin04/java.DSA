import java.util.*;
class Node{
    char data;
    Node next;
    Node (char data){
        this.data=data;
        this.next=null;
    }
}
class Stackll{
    Node top;
   void push(char ch){
   Node newNode=new Node(ch);
       newNode.next=top;
       top=newNode;
   }
   char pop(){
       if(top==null){
           return'\0';
   }
   char val=top.data;
    top=top.next;
    return val;
   }
   boolean isEmpty(){
       return top==null;
   }
   }
   public class balancedparatheses{
       static boolean isBalanced(String exp) {
           Stackll stack=new Stackll();
           for(int i=0;i<exp.length();i++){
               char ch =exp.charAt(i);
        if(ch=='('||ch=='{'||ch=='['){
            stack.push(ch);
        }
        else if(ch==')'||ch=='}'||ch==']'){
            if(stack.isEmpty()){
                return false;
            }
            char top=stack.pop();
        if((ch==')'&&top!='(')||
       (ch=='}'&&top!='{')||
       (ch==']'&&top!='[')){
           return false;
       }
    }
 }
   return stack.isEmpty();
}
    public static void main(String[] args) {
        String exp = "{[()]}";
        System.out.println(isBalanced(exp)); 
   }
}