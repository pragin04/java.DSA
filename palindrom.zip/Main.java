import java.util.*;
class Node {
	int data;
	Node prev;
	Node next;
	Node(int val) {
		data = val;
		prev = null;
		next = null;
	}
}
class DoublyLinkedList {
	Node head;
	DoublyLinkedList() {
		head = null;
	}
	void insert(int val) {
		Node newNode = new Node(val);
		if (head == null) {
			head = newNode;
			return;
		}
		Node temp = head;
		while (temp.next != null) {
			temp = temp.next;
		}
		temp.next = newNode;
		newNode.prev = temp;
	}
	boolean isPalindrome() {
		if (head == null)
			return true;
		Node left = head;
		Node right = head;
		while (right.next != null) {
			right = right.next;
		}
		while (left != right && left.prev != right) {
			if (left.data != right.data)
				return false;
			left = left.next;
			right = right.prev;
		}
		return true;
	}
}
public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		DoublyLinkedList l = new DoublyLinkedList  ();
		int val;
		do {
			val = sc.nextInt();
			if (val != -1)
				l.insert(val);
		} while (val != -1);
		if (l.isPalindrome())
			System.out.println("Palindrome");
		else
			System.out.println("Not Palindrome");
	}
}