import java.util.Scanner;

class Node {
    int data;
    Node prev;
    Node next;

    Node(int val) {
        data = val;
        prev = null;
        next = null;
    }
}

class DoublyLinkedList {
    Node head;

    DoublyLinkedList() {
        head = null;
    }

    void insert(int val) {
        Node newNode = new Node(val);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
        newNode.prev = temp;
    }

    void display() {
        if (head == null) {
            System.out.println("Linked list is empty");
            return;
        }

        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
    }
}
   

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DoublyLinkedList l = new DoublyLinkedList();
        int val;

        do {
            val = sc.nextInt();
            if (val != -1)
                l.insert(val);
        } while (val != -1);

        l.display();
    }
}