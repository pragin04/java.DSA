import java.util.*;
class Node{
    char data;
  Node next;
  Node(char ch){
   this.data=ch;
   this.next=null;
  }
  } class Stackll{
      Node top;
       void push (char ch){
           Node newNode=new Node(ch);
           newNode.next=top;
            top= newNode;
       }
      char pop(){
           if(top==null){
               return '\0';
           }
           char data=top.data;
           top=top.next;
           return data;
       }
        boolean isEmpty() {
        return top == null;
    }
  }
 class ReverseStringStackll{
      static String reverseString(String str){
      Stackll stack=new Stackll();
      for(int i=0;i<str.length();i++){
      stack.push (str.charAt(i));
  }
  StringBuilder sb= new StringBuilder();
  while(!stack.isEmpty()){
      sb.append(stack.pop());
  }
   return sb.toString();
  }
  public static void main(String []args){
      String str="hello";
      System.out.println(reverseString(str));
  }
  }
