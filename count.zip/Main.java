🔹 import java.util.Scanner;

👉 User kitta irundhu input vaanga (keyboard input)

🔹 class Node {

👉 Linked List-oda single node structure

int data;

👉 Node-la store panna value

Node next;

👉 Next node-oda address
👉 Last node-ku next = null

Node(int data) {

👉 Constructor
👉 Pudhu node create pannumbodhu call aagum

this.data = data;

👉 Constructor-la vandha value-a
👉 current node-oda data-la store panna

this.next = null;

👉 Pudhu node create pannumbodhu
👉 Next node illa → null

🔹 public class CountNodes {

👉 Main program start aagura class

🔹 static int countNodes(Node head) {

👉 Nodes count panna method
👉 head → linked list-oda first node

int count = 0;

👉 Nodes count store panna variable
👉 Starting-la 0

Node temp = head;

👉 head-a disturb pannaama traverse panna
👉 temp temporary pointer

while (temp != null) {

👉 Linked list mudiyura varaikum loop
👉 null vandhaa stop

count++;

👉 Oru node traverse panninaa
👉 count +1

temp = temp.next;

👉 Next node-ku move aaga

}

👉 while loop close

return count;

👉 Total node count return pannum

🔹 public static void main(String[] args) {

👉 Program execution start point

Scanner sc = new Scanner(System.in);

👉 Keyboard input vaanga scanner object

int n = sc.nextInt();

👉 Evlo nodes create panna porom nu user sollra number

Node head = null, tail = null;

👉 head → first node
👉 tail → last node
👉 Starting-la list empty

for (int i = 0; i < n; i++) {

👉 n times loop
👉 n nodes create panna

int val = sc.nextInt();

👉 Each node-oda value vaanga

Node newNode = new Node(val);

👉 Pudhu node create pannrom
👉 data = val, next = null

if (head == null) {

👉 List empty-aa irundhaa

head = tail = newNode;

👉 First node-aa irundhaa
👉 head & tail rendu perum same node

} else {

👉 Already nodes irundhaa

tail.next = newNode;

👉 Old last node-oda next-la
👉 new node connect pannrom

tail = newNode;

👉 Tail-a new last node-aa update pannrom

}

👉 if-else close

}

👉 for loop close

System.out.println(countNodes(head));

👉 Linked list-oda
👉 total nodes count print pannum

sc.close();

👉 Scanner close pannrom (good practice)