/*import java.util.*;
public class Main {
    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    Node head = null;

    void insertEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            newNode.next = head;
            return;
        }
        Node temp = head;
        while (temp.next != head) {
            temp = temp.next;
        }
        temp.next = newNode;
        newNode.next = head;
    }
  
    void split() {   
        if (head == null || head.next == head) {
            System.out.println("List too small to split");
            return;
        }
        Node slow = head;
        Node fast = head;
        while (fast.next != head && fast.next.next != head) {
            slow = slow.next;
            fast = fast.next.next;
        }
        if (fast.next.next == head) {
            fast = fast.next;
        }
        Node head1 = head;
        Node head2 = slow.next;
        slow.next = head1;  
        fast.next = head2;  
        System.out.println("First Half:");
        display(head1);
        System.out.println("Second Half:");
        display(head2);
    }
   
    void display(Node s) {
        Node temp = s;
        do {
            System.out.print(temp.data + " ");
            temp = temp.next;
        } while (temp != s);
        System.out.println();
    }
    public static void main(String[] args) {

        Main list = new Main();  
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter elements (-1 to stop):");
        while (true) {
            int val = sc.nextInt();
            if (val == -1)
                break;
            list.insertEnd(val);
        }
        list.split();   
    }
}*/
import java.util.*;
public class Main {
    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    Node head = null;

    void insertEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newNode;
    }
    void reverse() {
        Node prev = null;
        Node curr = head;
        Node next = null;

        while (curr != null) {
            next = curr.next;   
            curr.next = prev;  
            prev = curr;        
            curr = next;       
        }
        head = prev;
    }
    void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
    }
    public static void main(String[] args) {
        Main list = new Main();
        Scanner sc = new Scanner(System.in);
        while (true) {
            int val = sc.nextInt();
            if (val == -1)
                break;
            list.insertEnd(val);
        }
        list.reverse();
        list.display();
    }
}




























