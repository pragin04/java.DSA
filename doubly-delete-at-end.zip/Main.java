import java.util.*;

class Main {

    static class Node {
        int data;
        Node prev;
        Node next;

        Node(int data) {
            this.data = data;
        }
    }

    static Node head = null;

   
    public static void insertAtEnd(int value) {
        Node newNode = new Node(value);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
        newNode.prev = temp;
    }

   
    public static void deleteAtPosition(int pos) {

        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        Node temp = head;

        if (pos == 1) {
            head = temp.next;
            if (head != null) {
                head.prev = null;
            }
            return;
        }

        for (int i = 1; temp != null && i < pos; i++) {
            temp = temp.next;
        }
        if (temp == null) {
            System.out.println("Invalid Position");
            return;
        }

        
        if (temp.next != null) {
            temp.next.prev = temp.prev;
        }

        if (temp.prev != null) {
            temp.prev.next = temp.next;
        }
    }

   
    public static void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();  

        for (int i = 0; i < n; i++) {
            insertAtEnd(sc.nextInt());
        }

        int pos = sc.nextInt();   

        deleteAtPosition(pos);

        display();

        sc.close();
    }
}
